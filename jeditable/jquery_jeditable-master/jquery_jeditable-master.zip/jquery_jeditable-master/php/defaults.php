<?php

/* These are defaults for demonstrating purposes. */

$default['paragraph_1'] = 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.';
$default['paragraph_3'] = $default['paragraph_1'];

$default['paragraph_2'] = 'Lorem ipsum dolor sit amet, consectetuer adipiscing _elit, sed diam nonummy nibh_ euismod *tincidunt ut laoreet dolore magna aliquam* erat volutpat.

* Foo
* Bar

Duis autem vel eum in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto.
';
